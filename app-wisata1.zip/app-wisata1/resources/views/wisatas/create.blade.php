@extends('wisatas.layout')
@section('content')
    <form action="{{ route('wisata.store') }}" enctype="multipart/form-data" method="post">
        @csrf
        <label for="" class="label-control">Nama</label>
        <input type="text" name="nama" id="" class="form-control"><br>
        <label for="" class="label-control">Kota</label>
        <input type="text" name="kota" id="" class="form-control"><br>
        <label for="" class="label-control">Harga Tiket</label>
        <input type="text" name="harga_tiket" id="" class="form-control"><br>
        <label for="" class="label-control">Gambar</label>
        <input type="file" name="image" id="" class="form-control"><br>
        <a href="{{ route('wisata.index') }}" class="btn btn-secondary">Back</a>
        <input type="submit" value="save" class="btn btn-success">
    </form>
@endsection
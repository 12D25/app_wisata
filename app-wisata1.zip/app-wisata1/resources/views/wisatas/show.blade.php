@extends('wisatas.layout')
@section('content')
<img src="{{ Storage::url('public/images/' . $wisata->image) }}" style="width:350px"></td>
<p> Nama obyek wisata = {{ $wisata->nama }}</p>
<p>Terletak di Kota {{ $wisata->kota }}</p>
<p>Harga tiket masuk Rp.{{ $wisata->harga_tiket }}</p>
<a href="{{ route('wisata.index') }}" class="btn btn-secondary">back</a>
@endsection
    

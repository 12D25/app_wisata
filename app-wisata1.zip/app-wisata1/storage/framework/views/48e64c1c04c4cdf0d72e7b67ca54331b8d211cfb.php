<?php $__env->startSection('content'); ?>
<img src="<?php echo e(Storage::url('public/images/' . $wisata->image)); ?>" style="width:350px"></td>
<p> Nama obyek wisata = <?php echo e($wisata->nama); ?></p>
<p>Terletak di Kota <?php echo e($wisata->kota); ?></p>
<p>Harga tiket masuk Rp.<?php echo e($wisata->harga_tiket); ?></p>
<a href="<?php echo e(route('wisata.index')); ?>" class="btn btn-secondary">back</a>
<?php $__env->stopSection(); ?>
    

<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app-wisata1/resources/views/wisatas/show.blade.php ENDPATH**/ ?>
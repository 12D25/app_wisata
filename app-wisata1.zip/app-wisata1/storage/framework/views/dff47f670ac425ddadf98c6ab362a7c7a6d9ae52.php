<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('wisata.create')); ?>" class="btn btn-primary">Add New</a>
    <table class="table table-borderd">
        <tr class="table table-dark">
            <td>Id</td>
            <td>Nama</td>
            <td>Kota</td>
            <td>Harga Tiket</td>
            <td>Gambar</td>
            <td>Aksi</td>
        </tr>
        <?php $__currentLoopData = $wisatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wisata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($wisata->id); ?></td>
                <td><?php echo e($wisata->nama); ?></td>
                <td><?php echo e($wisata->kota); ?></td>
                <td><?php echo e($wisata->harga_tiket); ?></td>
                <td><img src="<?php echo e(Storage::url('public/images/' . $wisata->image)); ?>" style="width:150px"></td>
                <td>
                    <a href="<?php echo e(route('wisata.show', $wisata->id)); ?>" class="btn btn-info">Show</a>
                    <a href="<?php echo e(route('wisata.edit', $wisata->id)); ?>" class="btn btn-warning">Edit</a>
                    <form action="<?php echo e(route('wisata.destroy', $wisata->id)); ?>" onclick="return confirm('r u sure?')" style="display: inline" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($wisatas->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app-wisata1/resources/views/wisatas/index.blade.php ENDPATH**/ ?>
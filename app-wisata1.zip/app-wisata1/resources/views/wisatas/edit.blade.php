@extends('wisatas.layout')
@section('content')
    <form action="{{ route('wisata.update', $wisata->id) }}" enctype="multipart/form-data" method="post">
        @csrf
        @method('PUT')
        <label for="" class="label-control">Nama</label>
        <input type="text" name="nama" id="" class="form-control" value="{{ $wisata->nama }}"><br>
        <label for="" class="label-control">Kota</label>
        <input type="text" name="kota" id="" class="form-control" value="{{ $wisata->kota }}"><br>
        <label for="" class="label-control">Harga Tiket</label>
        <input type="text" name="harga_tiket" id="" class="form-control" value="{{ $wisata->harga_tiket }}"><br>
        <label for="" class="label-control">Gambar</label>
        <input type="file" name="image" id="" class="form-control"><br>
        <a href="{{ route('wisata.index') }}" class="btn btn-secondary">Back</a>
        <input type="submit" value="save" class="btn btn-success">
    </form>
@endsection
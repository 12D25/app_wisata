<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('wisata.store')); ?>" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>
        <label for="" class="label-control">Nama</label>
        <input type="text" name="nama" id="" class="form-control"><br>
        <label for="" class="label-control">Kota</label>
        <input type="text" name="kota" id="" class="form-control"><br>
        <label for="" class="label-control">Harga Tiket</label>
        <input type="text" name="harga_tiket" id="" class="form-control"><br>
        <label for="" class="label-control">Gambar</label>
        <input type="file" name="image" id="" class="form-control"><br>
        
        <input type="submit" value="save" class="btn btn-success">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app-wisata1/resources/views/wisatas/create.blade.php ENDPATH**/ ?>
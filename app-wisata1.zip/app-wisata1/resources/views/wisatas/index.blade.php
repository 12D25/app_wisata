@extends('wisatas.layout')
@section('content')
    <a href="{{ route('wisata.create') }}" class="btn btn-primary">Add New</a>
    <table class="table table-borderd">
        <tr class="table table-dark">
            <td>Id</td>
            <td>Nama</td>
            <td>Kota</td>
            <td>Harga Tiket</td>
            <td>Gambar</td>
            <td>Aksi</td>
        </tr>
        @foreach ($wisatas as $wisata)
            <tr>
                <td>{{ $wisata->id }}</td>
                <td>{{ $wisata->nama }}</td>
                <td>{{ $wisata->kota }}</td>
                <td>{{ $wisata->harga_tiket }}</td>
                <td><img src="{{ Storage::url('public/images/' . $wisata->image) }}" style="width:150px"></td>
                <td>
                    <a href="{{ route('wisata.show', $wisata->id) }}" class="btn btn-info">Show</a>
                    <a href="{{ route('wisata.edit', $wisata->id) }}" class="btn btn-warning">Edit</a>
                    <form action="{{ route('wisata.destroy', $wisata->id) }}" onclick="return confirm('r u sure?')" style="display: inline" method="post">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
    {{ $wisatas->links() }}
@endsection
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('wisata.update', $wisata->id)); ?>" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="" class="label-control">Nama</label>
        <input type="text" name="nama" id="" class="form-control" value="<?php echo e($wisata->nama); ?>"><br>
        <label for="" class="label-control">Kota</label>
        <input type="text" name="kota" id="" class="form-control" value="<?php echo e($wisata->kota); ?>"><br>
        <label for="" class="label-control">Harga Tiket</label>
        <input type="text" name="harga_tiket" id="" class="form-control" value="<?php echo e($wisata->harga_tiket); ?>"><br>
        <label for="" class="label-control">Gambar</label>
        <input type="file" name="image" id="" class="form-control"><br>
        <a href="<?php echo e(route('wisata.index')); ?>" class="btn btn-secondary">Back</a>
        <input type="submit" value="save" class="btn btn-success">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app-wisata1/resources/views/wisatas/edit.blade.php ENDPATH**/ ?>